#ifndef TIME_TRACKER_H
#define TIME_TRACKER_H

#include<iostream>
#include<cstdlib>
#include<sys/time.h>

using namespace std; 

void startTimer(void);
double stopTimer();
#endif
